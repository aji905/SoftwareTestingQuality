package projectsda;


import java.io.Serializable;

public class Customer implements Serializable{

    /**
     * @return the noRekening
     */
    public String getNoRekening() {
        return noRekening;
    }

    private final String namaDepan;
    private final String namaBelakang;
    private final String noRekening;
    private final Account account;
    Customer(String namaDepan, String namaBelakang, String noRekening, Account account){
        this.namaDepan = namaDepan;
        this.namaBelakang = namaBelakang;
        this.noRekening = noRekening;
        this.account = account;
    }
    
    @Override
    public String toString(){
        return "\n Customer Information" + 
                " Nama Depan : " + getNamaDepan() + "\n" +
                " Nama Belakang : " + getNamaBelakang() + "\n" +
                " Nomor Rekening : " + getNoRekening() + "\n" +
                account;
                
    }
    
    public String basicInfo(){
        return " Nomor account: " + account.getNomorAccount() + " - Nama: " + getNamaDepan() + " " + getNamaBelakang(); 
                
                
    }
    Account getAccount(){
        return account;
    }
    
    /**
     * @return the namaDepan
     */
    public String getNamaDepan() {
        return namaDepan;
    }

    /**
     * @return the namaBelakang
     */
    public String getNamaBelakang() {
        return namaBelakang;
    }
}
