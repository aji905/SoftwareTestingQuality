package projectsda;

public class Checking extends Account{
    private static String tipeAccount = "checking";
    
    Checking(double initialDeposit){
        this.setTabungan(initialDeposit);
        this.checkInterest(0);
        this.setBiayaTransaksi(3000);
    }
    
    @Override
    public String toString(){
        return "Tipe Account: " + tipeAccount + " Account\n" +
                "Nomor Account " + this.getNomorAccount() + "\n" +
                "Tabungan: " + this.getTabungan() + "\n" +
                "Interest rate: " + (this.getInterest() * 100)+ "%\n";
    }

    @Override
    public String getTipeAccount() {
        return tipeAccount;
    }
}
