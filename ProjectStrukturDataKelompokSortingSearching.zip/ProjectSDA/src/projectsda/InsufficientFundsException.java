package projectsda;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author NANA
 */
public class InsufficientFundsException extends Exception {

    public InsufficientFundsException() {
        super("Jumlah tidak cukup untuk melakukan transaksi");
    }
    
}
