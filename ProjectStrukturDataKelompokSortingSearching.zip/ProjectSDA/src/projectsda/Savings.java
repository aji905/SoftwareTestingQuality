package projectsda;

public class Savings extends Account{
    private static String tipeAccount = "savings";
    
    Savings(double initialDeposit){
        this.setTabungan(initialDeposit);
        this.checkInterest(0);
        this.setBiayaTransaksi(3000);
    }
    
    @Override
    public String toString(){
        return "Tipe Account: " + tipeAccount + "Account\n" +
                "Nomor Account " + this.getNomorAccount() + "\n" +
                "Tabungan: " + this.getTabungan() + "\n" +
                "Interest rate: " + this.getInterest() + "%\n";
    }

    @Override
    public String getTipeAccount() {
        return tipeAccount;   
        }
}
