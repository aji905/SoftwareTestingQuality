package projectsda;


import java.io.Serializable;

public abstract class Account implements Serializable{
    private double tabungan = 0; 
    private double interest =  0.02;
    private int nomorAccount;
    private static int jumlahAccount = 1000000;
    private double biayaTransaksi;
    
    Account(){
        nomorAccount = getNextNomorAccount();
    }
    
    public abstract String getTipeAccount();
    
    public static int getNextNomorAccount(){
        return ++jumlahAccount;
    }
    /**
     * @return the tabungan
     */
    public double getTabungan() {
        return tabungan;
    }
    
    

    /**
     * @param tabungan the tabungan to set
     */
    public void setTabungan(double tabungan) {
        this.tabungan = tabungan;
    }

    /**
     * @return the interest
     */
    public double getInterest() {
        return interest;
    }

    /**
     * @param interest the interest to set
     */
    public void setInterest(double interest) {
        this.interest = interest;
    }

    /**
     * @return the nomorAccount
     */
    public int getNomorAccount() {
        return nomorAccount;
    }
    
    public void withdraw(double jumlah) throws InsufficientFundsException{
        if(jumlah + biayaTransaksi > tabungan){
            throw new InsufficientFundsException();
        }
        tabungan -= jumlah + biayaTransaksi;
        checkInterest(0);
        
    }
    
    public void deposit(double jumlah) throws InvalidAmountException{
        if(jumlah <= 0){
            throw new InvalidAmountException();
        }
        checkInterest(jumlah);
        jumlah = jumlah + jumlah * interest;
        tabungan += jumlah;
    }
    
    public void checkInterest(double jumlah){
        if(tabungan + jumlah > 1000000000){
            interest = 0.05;
        }
        else{
            interest = 0.02;
        }
    }

    Object[] getTransactionFee() {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public double getBiayaTransaksi() {
        return  biayaTransaksi;
    }
    
    public void setBiayaTransaksi(double biaya){
        this.biayaTransaksi=biaya;
    }

    void setAccountNumber(int nomorAccount) {
        this.nomorAccount = nomorAccount;
    }
}